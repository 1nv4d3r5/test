<?php

$downloads="downloads";
$gallery="gallery";
$links="links";
$news="news";
$survey="survey";
$uploads="uploads";
$dropdown="dropdown";
?>
