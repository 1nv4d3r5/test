<?php
$MySQL=1;
$databasename="white";
$databaselogin="root";
$databasepassword="";
$databasehost="localhost";
$prefix="LNE_";
?>
