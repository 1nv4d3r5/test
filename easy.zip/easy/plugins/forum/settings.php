<?php
$forumname="Smart Academy";
$forumwidth="95%";
$posterlevel=2;
$adminlevel=3;
$forumtemplate="blue.css";
?>
