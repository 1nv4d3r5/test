<?php
/* language file for forum plugin */
$forummessage[1] ="Forum setup";
$forummessage[2] ="Forum name";
$forummessage[3] ="Forum width";
$forummessage[4] ="Back";
$forummessage[5] ="Topics";
$forummessage[6] ="Posts";
$forummessage[7] ="Add Forum";
$forummessage[8] ="Forums";
$forummessage[9] ="posted at";
$forummessage[10]="by";
$forummessage[11]="Add Topic";
$forummessage[12]="Created at";
$forummessage[13]="Topic";
$forummessage[14]="Message";
$forummessage[15]="Cancel";
$forummessage[16]="Add";
$forummessage[17]="Add Post";
$forummessage[18]="Poster level";
$forummessage[19]="Admin level";
$forummessage[20]="Submit";
$forummessage[21]="Color theme";
$forummessage[22]="Description";
$forummessage[23]="Index";
$forummessage[24]="Delete";
$forummessage[25]="Delete post";
$forummessage[26]="Delete topic";
$forummessage[27]="Caution: all posts for this topic will also be deleted!";
$forummessage[28]="Delete forum";
$forummessage[29]="Caution: all topics and posts for this forum will also be deleted!";
$forummessage[30]="Last";
$forummessage[31]="Edit post";
$forummessage[32]="Hacking attempt!";
?>
